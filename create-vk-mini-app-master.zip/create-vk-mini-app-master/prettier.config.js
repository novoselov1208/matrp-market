module.exports = require('@vkontakte/prettier-config').createConfig(100);
